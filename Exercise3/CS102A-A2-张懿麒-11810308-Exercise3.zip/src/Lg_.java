public class Lg_ {
    public static int lg (double n){
        return (int)(Math.log(n)/Math.log(2));
    }
}
