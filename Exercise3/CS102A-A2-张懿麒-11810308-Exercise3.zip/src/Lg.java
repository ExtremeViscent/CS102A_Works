public class Lg {
    public static double lg(double n){
        return (Math.log(n)/Math.log(2));
    }
}
