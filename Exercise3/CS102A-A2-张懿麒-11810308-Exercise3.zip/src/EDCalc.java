public class EDCalc {
    public static void main(String args[]){
        int[] a=new int[2],b= new int[2];
        /*Codes to give a/b value*/
        double ED=Math.sqrt(Math.pow((a[1]-b[1]),2)+Math.pow((a[0]-b[0]),2));
    }
}
