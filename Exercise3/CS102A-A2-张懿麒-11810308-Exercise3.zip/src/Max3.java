public class Max3 {
    public static int max3(int a,int b,int c){
        int max=Math.max(a,b);
        max=Math.max(max,c);
        return max;
    }
    public static double max3(double a,double b,double c){
        double max=Math.max(a,b);
        max=Math.max(max,c);
        return max;
    }
}
